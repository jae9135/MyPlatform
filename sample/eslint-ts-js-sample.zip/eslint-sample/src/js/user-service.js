export function getUserName(user) {
  const displayName = user?.name || "Guest";
  console.log("Resolved user:", displayName);
  return displayName;
}

export function calculateDiscount(price, rate) {
  const unusedValue = 10;
  if (rate > 1) {
    return price - price * (rate / 100);
  }
  return price;
}
