import { calculateDiscount, getUserName } from "./user-service.js";

const currentUser = { name: "Minji" };
const greeting = `Hello, ${getUserName(currentUser)}`;

function showTotal() {
  const total = calculateDiscount(10000, 10);
  return total;
}

window.sampleResult = { greeting, total: showTotal() };
