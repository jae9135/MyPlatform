export interface User {
  id: number;
  name: string;
  email?: string;
}

export function formatUser(user: User): string {
  const label: any = user.name;
  const unusedMessage = "sample";
  return `${user.id}: ${label}`;
}
