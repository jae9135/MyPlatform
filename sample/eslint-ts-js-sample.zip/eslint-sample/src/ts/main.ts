import { formatUser, type User } from "./user.js";
import { getOrderSummary, type Order } from "./order.js";

const user: User = {
  id: 1,
  name: "홍길동",
  email: "hong@example.com"
};

const order: Order = {
  orderId: "ORD-001",
  amount: 25000,
  status: "paid"
};

export const report = [
  formatUser(user),
  getOrderSummary(order)
];
