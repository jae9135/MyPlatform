export type OrderStatus = "pending" | "paid" | "cancelled";

export interface Order {
  orderId: string;
  amount: number;
  status: OrderStatus;
}

export function getOrderSummary(order: Order): string {
  if (order.amount < 0) {
    throw new Error("Amount cannot be negative");
  }

  return `${order.orderId}: ${order.status} (${order.amount})`;
}
