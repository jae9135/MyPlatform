# ESLint TypeScript / JavaScript 샘플

ESLint 9의 Flat Config(`eslint.config.mjs`)를 사용하는 간단한 점검용 프로젝트입니다.
일부 파일에는 ESLint 경고/오류를 확인할 수 있도록 의도적인 점검 대상 코드가 포함되어 있습니다.

## 실행 방법

```bash
npm install
npm run lint
```

자동 수정 가능한 항목을 수정하려면:

```bash
npm run lint:fix
```

## 구성

- `src/js/`: JavaScript 샘플
- `src/ts/`: TypeScript 샘플
- `eslint.config.mjs`: ESLint 설정
- `tsconfig.json`: TypeScript 설정

## 참고

이 샘플은 ESLint 규칙 동작 확인용입니다. 프로젝트에 적용할 때는 기존 빌드 도구,
프레임워크(예: Next.js), TypeScript 버전에 맞춰 설정을 조정하세요.
